"""
database.py
------------
Handles everything related to talking to the SQLite database:
creating tables, and inserting/reading job descriptions and resumes.

Keeping all database code in one file (instead of scattering SQL
queries across the project) makes it easy to find and change later.
"""

import sqlite3
from datetime import datetime

from config import DB_PATH


def get_connection():
    """
    Opens and returns a connection to the SQLite database.
    Each function below opens its own short-lived connection and
    closes it when done — the simplest safe pattern for a small
    script-based project like this MVP.
    """
    return sqlite3.connect(DB_PATH)


def init_db():
    """
    Creates the database tables if they don't already exist.
    Safe to call every time the program starts — it won't wipe
    existing data, and won't error if the tables are already there.
    """
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS resumes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            raw_text TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    connection.commit()
    connection.close()


def insert_job(title, description):
    """
    Saves one job description to the database.
    Returns the new row's id, in case we need to refer to it later.
    """
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        "INSERT INTO jobs (title, description, created_at) VALUES (?, ?, ?)",
        (title, description, datetime.now().isoformat())
    )

    connection.commit()
    new_id = cursor.lastrowid
    connection.close()
    return new_id


def insert_resume(filename, raw_text):
    """
    Saves one resume's extracted text to the database.
    Returns the new row's id.
    """
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        "INSERT INTO resumes (filename, raw_text, created_at) VALUES (?, ?, ?)",
        (filename, raw_text, datetime.now().isoformat())
    )

    connection.commit()
    new_id = cursor.lastrowid
    connection.close()
    return new_id


def get_all_resumes():
    """
    Returns every resume stored so far, as a list of
    (id, filename, raw_text) tuples. Phase 2 (the scoring engine)
    will use this to compare each resume against a job description.
    """
    connection = get_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT id, filename, raw_text FROM resumes")
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_latest_job():
    """
    Returns the most recently added job description as
    (id, title, description), or None if no job has been added yet.
    """
    connection = get_connection()
    cursor = connection.cursor()
    cursor.execute(
        "SELECT id, title, description FROM jobs ORDER BY id DESC LIMIT 1"
    )
    row = cursor.fetchone()
    connection.close()
    return row
