"""
fairness.py
------------
Phase 4: removes the candidate's name and gendered language from
resume text before it's used for scoring, so the match score
reflects skills and experience — not who the candidate is.

Important: this only affects the COPY of the text used for scoring
in scoring.py. The original resume text stays untouched in the
database, so nothing about the candidate's actual resume is lost or
overwritten.
"""

import re

from config import GENDERED_TERMS


def redact_name_line(text: str) -> str:
    """
    Removes the first non-empty line of the resume.

    This is a simple heuristic: most resumes put the candidate's name
    as the very first line (our own sample resumes do exactly this).
    It won't catch every resume format, but it removes the single
    most obvious identifier with zero extra dependencies — a proper
    name-detection model (NER) is a reasonable upgrade for a later
    phase.
    """
    lines = text.splitlines()

    for index, line in enumerate(lines):
        if line.strip():
            lines[index] = "[NAME REMOVED]"
            break

    return "\n".join(lines)


def redact_gendered_terms(text: str) -> str:
    """
    Replaces gendered honorifics, pronouns, and identity words (the
    GENDERED_TERMS list in config.py) with a neutral placeholder.

    \\b (word boundary) matching means we replace whole words only —
    so "her" is redacted on its own, but not as part of "there" or
    "herbal".
    """
    redacted = text
    for term in GENDERED_TERMS:
        pattern = r"\b" + re.escape(term) + r"\b"
        redacted = re.sub(pattern, "[REDACTED]", redacted, flags=re.IGNORECASE)
    return redacted


def anonymize_resume_text(text: str) -> str:
    """
    Runs both redaction steps and returns the anonymized text that
    scoring.py uses in place of the raw resume text when computing
    match scores.
    """
    text = redact_name_line(text)
    text = redact_gendered_terms(text)
    return text
