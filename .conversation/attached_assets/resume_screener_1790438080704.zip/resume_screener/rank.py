"""
rank.py
--------
Phase 2 entry point.

Loads the most recent job description and every resume from the
database (both saved by Phase 1's ingest.py), scores each resume
against the job description using TF-IDF + cosine similarity, and
prints a ranked table with each resume's matched keywords.

Run this from the project's root folder with:
    python rank.py
"""

from database import get_latest_job, get_all_resumes
from scoring import score_resumes


def print_results_table(job_title, results):
    """
    Prints a simple, readable table of ranked resumes to the terminal.
    A dedicated Flask page will replace this printout in Phase 3, but
    this is the fastest way to check the scoring logic works correctly.
    """
    print(f"Ranking resumes against: '{job_title}'\n")
    print(f"{'Rank':<5}{'Score %':<10}{'Filename':<25}Matched keywords")
    print("-" * 70)

    for rank, result in enumerate(results, start=1):
        keywords_display = ", ".join(result["matched_keywords"]) or "(none)"
        print(
            f"{rank:<5}{result['score']:<10}{result['filename']:<25}{keywords_display}"
        )


def main():
    job = get_latest_job()
    if job is None:
        print("No job description found. Run ingest.py first.")
        return

    job_id, job_title, job_description = job

    resumes = get_all_resumes()
    if not resumes:
        print("No resumes found. Run ingest.py first.")
        return

    results = score_resumes(job_description, resumes)
    print_results_table(job_title, results)


if __name__ == "__main__":
    main()
