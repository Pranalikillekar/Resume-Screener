"""
ingest.py
----------
Phase 1 entry point.

What this does:
1. Makes sure the database and its tables exist.
2. Reads the job description from data/job_description.txt and saves it.
3. Reads every resume in data/resumes/ (PDF or TXT), extracts its text,
   and saves it.
4. Prints a short summary so you can confirm everything landed in the
   database correctly.

Run this from the project's root folder with:
    python ingest.py
"""

from config import DATA_DIR, RESUME_DIR, JOB_DESCRIPTION_FILE
from database import init_db, insert_job, insert_resume
from text_extractor import extract_text, clean_text, is_supported_file


def ensure_folders_exist():
    """
    Creates the data/ and data/resumes/ folders if they don't exist
    yet, so a first-time run doesn't crash just because a folder is
    missing.
    """
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    RESUME_DIR.mkdir(parents=True, exist_ok=True)


def ingest_job_description():
    """
    Reads data/job_description.txt and saves it to the jobs table.
    The file's first line is used as the job title; the rest of the
    file is the full description.
    """
    if not JOB_DESCRIPTION_FILE.exists():
        print(
            f"No job description found at {JOB_DESCRIPTION_FILE}.\n"
            "Create that file (first line = job title, rest = "
            "description) and run this script again."
        )
        return False

    raw_text = JOB_DESCRIPTION_FILE.read_text(encoding="utf-8", errors="ignore")
    lines = raw_text.strip().splitlines()

    if not lines:
        print("job_description.txt is empty — please add content to it.")
        return False

    title = lines[0].strip()
    description = "\n".join(lines[1:]).strip() or title

    job_id = insert_job(title, description)
    print(f"Saved job description (id={job_id}, title='{title}')")
    return True


def ingest_resumes():
    """
    Loops through every file in data/resumes/, extracts its text, and
    saves each one to the resumes table. Files we don't know how to
    read (wrong extension) are skipped with a warning instead of
    crashing the whole run.
    """
    resume_files = [f for f in RESUME_DIR.iterdir() if f.is_file()]

    if not resume_files:
        print(
            f"No resumes found in {RESUME_DIR}.\n"
            "Add some .pdf or .txt resumes there and run this script again."
        )
        return 0

    saved_count = 0
    for filepath in resume_files:
        if not is_supported_file(filepath):
            print(f"Skipping unsupported file: {filepath.name}")
            continue

        try:
            raw_text = extract_text(filepath)
            cleaned = clean_text(raw_text)

            if not cleaned:
                print(f"Skipping {filepath.name} — no readable text found.")
                continue

            insert_resume(filepath.name, cleaned)
            saved_count += 1
            print(f"Saved resume: {filepath.name}")

        except Exception as error:
            # Caught per-file so one broken resume doesn't stop the
            # rest of the batch from being processed.
            print(f"Failed to process {filepath.name}: {error}")

    return saved_count


def main():
    print("Setting up database...")
    init_db()

    print("\nIngesting job description...")
    ingest_job_description()

    print("\nIngesting resumes...")
    saved_count = ingest_resumes()

    print(f"\nDone. {saved_count} resume(s) saved to the database.")


if __name__ == "__main__":
    ensure_folders_exist()
    main()
