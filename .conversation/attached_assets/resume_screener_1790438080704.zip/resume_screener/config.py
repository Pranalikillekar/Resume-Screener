"""
config.py
----------
Central place for all project settings.
Keeping these as variables (instead of hard-coding values inside other
files) means we can change a folder path or database name in ONE place
later, instead of hunting through every file.
"""

from pathlib import Path

# BASE_DIR points to the folder this config.py file lives in.
# Every other path in the project is built relative to this, so the
# project works no matter where it's copied to on disk.
BASE_DIR = Path(__file__).resolve().parent

# Folder where all input data lives (job description + resumes)
DATA_DIR = BASE_DIR / "data"

# Folder containing the resumes we want to screen
RESUME_DIR = DATA_DIR / "resumes"

# Path to the single job description text file for this MVP.
# (Phase 3's Flask app will let users upload this instead of using a
# fixed file.)
JOB_DESCRIPTION_FILE = DATA_DIR / "job_description.txt"

# SQLite database file — SQLite stores the whole database in one file,
# so no separate database server needs to be installed or running.
DB_PATH = BASE_DIR / "resume_screener.db"

# File types we know how to read text from in this phase
ALLOWED_EXTENSIONS = {".pdf", ".txt"}

# --- Phase 2: scoring settings ---

# Maximum number of distinct words the TF-IDF vectorizer will track.
# Keeping this bounded avoids the vocabulary growing unbounded as more
# resumes are added, and keeps scoring fast.
TFIDF_MAX_FEATURES = 500

# How many of the job description's most important words to check for
# in each resume, when showing "matched keywords" for explainability.
TOP_KEYWORDS_COUNT = 15

# --- Phase 3: Flask app settings ---

# Needed by Flask to sign session data (used here for flash messages).
# Fine as a plain string for local/dev use; a real deployment should
# load this from an environment variable instead.
SECRET_KEY = "dev-secret-key-change-this-before-deploying"

FLASK_DEBUG = True
FLASK_PORT = 5000

# --- Phase 4: fairness settings ---

# Words redacted from resume text before scoring, so gendered
# language doesn't influence the match score. Intentionally a simple
# word list rather than a full NLP model — good enough for an MVP,
# and easy to extend later.
GENDERED_TERMS = [
    "mr", "mrs", "ms", "miss",
    "he", "she", "him", "her", "his", "hers",
    "himself", "herself",
    "man", "woman", "male", "female",
    "husband", "wife", "boyfriend", "girlfriend",
    "sir", "madam"
]
