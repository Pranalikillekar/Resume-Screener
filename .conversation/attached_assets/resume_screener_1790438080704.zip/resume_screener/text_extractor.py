"""
text_extractor.py
------------------
Turns a resume file (PDF or TXT) into plain text we can store and
later compare against a job description.
"""

from pathlib import Path
import pdfplumber

from config import ALLOWED_EXTENSIONS


def is_supported_file(filepath: Path) -> bool:
    """Returns True if we know how to read text from this file type."""
    return filepath.suffix.lower() in ALLOWED_EXTENSIONS


def extract_text_from_pdf(filepath: Path) -> str:
    """
    Reads all pages of a PDF and joins their text together.
    pdfplumber handles most standard PDF resumes well; scanned
    (image-only) PDFs are a known limitation we can address later
    with OCR if needed.
    """
    pages_text = []
    with pdfplumber.open(filepath) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:  # a blank page can return None
                pages_text.append(page_text)
    return "\n".join(pages_text)


def extract_text_from_txt(filepath: Path) -> str:
    """Reads a plain text file using UTF-8 encoding."""
    return filepath.read_text(encoding="utf-8", errors="ignore")


def extract_text(filepath: Path) -> str:
    """
    Dispatcher function: looks at the file extension and calls the
    right extractor. This is the only function other files need to
    call — they don't need to know about PDF vs TXT internals.
    """
    if not is_supported_file(filepath):
        raise ValueError(f"Unsupported file type: {filepath.suffix}")

    if filepath.suffix.lower() == ".pdf":
        return extract_text_from_pdf(filepath)
    else:
        return extract_text_from_txt(filepath)


def clean_text(text: str) -> str:
    """
    Light cleanup of extracted text: collapses repeated whitespace and
    strips blank lines.

    This is deliberately minimal for Phase 1 — just tidying the text
    for storage. Heavier NLP cleaning (lowercasing, removing
    stopwords, etc.) happens in Phase 2, right before scoring, so the
    ORIGINAL wording stays intact in the database until then.
    """
    lines = [line.strip() for line in text.splitlines()]
    non_empty_lines = [line for line in lines if line]
    return "\n".join(non_empty_lines)
