"""
scoring.py
-----------
Turns a job description and a batch of resumes into ranked match
scores.

How it works (in plain terms):
1. TF-IDF ("Term Frequency - Inverse Document Frequency") turns each
   piece of text into a list of numbers, where words that are common
   across every document (like "the", "and") get a low weight, and
   words that are distinctive to a particular document get a high
   weight.
2. Cosine similarity then measures how close two of these number-lists
   are to each other — a score near 1.0 means "very similar wording",
   near 0.0 means "almost nothing in common".
3. We also pull out the job description's most distinctive words and
   check which of them actually appear in each resume, so we can show
   *why* a resume scored the way it did.
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from config import TFIDF_MAX_FEATURES, TOP_KEYWORDS_COUNT
from fairness import anonymize_resume_text


def get_top_job_keywords(vectorizer, job_vector, top_n):
    """
    Given the fitted vectorizer and the job description's TF-IDF
    vector, returns the top_n words with the highest TF-IDF weight
    in that job description — i.e. its most distinctive terms.
    """
    feature_names = vectorizer.get_feature_names_out()
    job_scores = job_vector.toarray()[0]

    # argsort gives indices from smallest to largest score, so we
    # reverse it to get largest-first, then take the first top_n.
    top_indices = job_scores.argsort()[::-1][:top_n]

    # A word with a score of 0 never actually appeared in the job
    # description, so we filter those out even if top_n asked for more.
    return [feature_names[i] for i in top_indices if job_scores[i] > 0]


def find_matched_keywords(keywords, resume_text):
    """
    Returns the subset of `keywords` that appear (case-insensitive)
    somewhere in the resume's raw text.
    """
    resume_lower = resume_text.lower()
    return [keyword for keyword in keywords if keyword in resume_lower]


def score_resumes(job_description, resumes):
    """
    job_description: the job description text (string)
    resumes: list of (resume_id, filename, raw_text) tuples,
             as returned by database.get_all_resumes()

    Returns a list of dicts, sorted by score (highest first):
        {
            "resume_id": ...,
            "filename": ...,
            "score": ...,          # 0-100, higher = better match
            "matched_keywords": [...]
        }
    """
    if not resumes:
        return []

    # Phase 4: score an ANONYMIZED copy of each resume (name and
    # gendered terms redacted) instead of the raw text, so the match
    # score is based on skills/experience rather than identity.
    resume_texts = [anonymize_resume_text(resume[2]) for resume in resumes]

    # We fit the vectorizer on the job description AND every resume
    # together, so that all the vectors share the same "vocabulary" —
    # otherwise there'd be no fair way to compare them.
    documents = [job_description] + resume_texts

    vectorizer = TfidfVectorizer(
        stop_words="english",
        max_features=TFIDF_MAX_FEATURES
    )
    tfidf_matrix = vectorizer.fit_transform(documents)

    # Row 0 is the job description; every row after that is a resume,
    # in the same order they were passed in.
    job_vector = tfidf_matrix[0:1]
    resume_vectors = tfidf_matrix[1:]

    similarity_scores = cosine_similarity(job_vector, resume_vectors)[0]

    top_job_keywords = get_top_job_keywords(
        vectorizer, job_vector, TOP_KEYWORDS_COUNT
    )

    results = []
    for (resume_id, filename, _), anonymized_text, similarity in zip(resumes, resume_texts, similarity_scores):
        matched_keywords = find_matched_keywords(top_job_keywords, anonymized_text)
        results.append({
            "resume_id": resume_id,
            "filename": filename,
            "score": round(float(similarity) * 100, 2),
            "matched_keywords": matched_keywords
        })

    results.sort(key=lambda result: result["score"], reverse=True)
    return results
