"""
app.py
-------
Phase 3: the Flask web app.

Lets you paste a job description and upload a batch of resumes in the
browser, then shows a ranked results page — the same scoring logic
from Phase 2 (scoring.py), just with a web front end instead of the
terminal.

Run this from the project's root folder with:
    python app.py
Then open http://127.0.0.1:5000 in your browser.
"""

from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename

from config import RESUME_DIR, SECRET_KEY, FLASK_DEBUG, FLASK_PORT
from database import init_db, insert_job, insert_resume
from text_extractor import extract_text, clean_text, is_supported_file
from scoring import score_resumes
from ingest import ensure_folders_exist

app = Flask(__name__)
app.secret_key = SECRET_KEY


@app.route("/", methods=["GET"])
def index():
    """Shows the form for entering a job description and uploading resumes."""
    return render_template("index.html")


@app.route("/screen", methods=["POST"])
def screen():
    """
    Handles the submitted form: saves the job description, saves and
    scores each uploaded resume, and shows the ranked results page.
    """
    job_title = request.form.get("job_title", "").strip()
    job_description = request.form.get("job_description", "").strip()

    if not job_title or not job_description:
        flash("Please fill in both the job title and job description.")
        return redirect(url_for("index"))

    uploaded_files = request.files.getlist("resumes")
    uploaded_files = [f for f in uploaded_files if f and f.filename]

    if not uploaded_files:
        flash("Please upload at least one resume.")
        return redirect(url_for("index"))

    # Save the job description for our records — the same thing
    # Phase 1's ingest.py does when run from the command line.
    insert_job(job_title, job_description)

    # We score only THIS batch of uploaded resumes, not every resume
    # ever uploaded, so each screening run is self-contained. Each
    # resume is still saved to the database for a permanent record.
    batch_resumes = []
    skipped_files = []

    for uploaded_file in uploaded_files:
        filepath = RESUME_DIR / secure_filename(uploaded_file.filename)

        if not is_supported_file(filepath):
            skipped_files.append(uploaded_file.filename)
            continue

        uploaded_file.save(filepath)

        try:
            raw_text = extract_text(filepath)
            cleaned = clean_text(raw_text)
        except Exception:
            skipped_files.append(uploaded_file.filename)
            continue

        if not cleaned:
            skipped_files.append(uploaded_file.filename)
            continue

        resume_id = insert_resume(filepath.name, cleaned)
        batch_resumes.append((resume_id, filepath.name, cleaned))

    if skipped_files:
        flash(f"Skipped unreadable or unsupported files: {', '.join(skipped_files)}")

    if not batch_resumes:
        flash("None of the uploaded files could be read. Please try different files.")
        return redirect(url_for("index"))

    results = score_resumes(job_description, batch_resumes)

    return render_template(
        "results.html",
        job_title=job_title,
        results=results
    )


if __name__ == "__main__":
    ensure_folders_exist()
    init_db()
    app.run(debug=FLASK_DEBUG, port=FLASK_PORT)
